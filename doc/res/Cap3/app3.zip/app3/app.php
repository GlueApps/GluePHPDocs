<?php

/////////////////
// Composición //
/////////////////

$app = new App('process.php');

$input = new Input('input');
$button = new Button('button');

$app->appendComponent('body', $input);
$app->appendComponent('body', $button);

////////////////////////////
// Vinculación de eventos //
////////////////////////////

$button->on('click', 'clickButton');

return $app;
