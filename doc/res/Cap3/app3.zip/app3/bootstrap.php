<?php

require_once 'vendor/autoload.php';

use GlueApps\GluePHP\AbstractApp;
use GlueApps\GluePHP\Component\AbstractComponent;

function clickButton($e)
{
    $newButton = new Button;
    $newButton->setText($e->app->input->getText());
    $newButton->on('click', 'clickNewButton');

    $e->app->appendComponent('body', $newButton);
}

function clickNewButton($e)
{
    $button = $e->component;
    $button->detach();
}

class App extends AbstractApp
{
    public function html(): ?string
    {
        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>My glue app</title>
</head>
<body>
    {$this->renderSidebar('body')}

    {$this->renderAssets('scripts')}
</body>
</html>
HTML;
    }
}

class Input extends AbstractComponent
{
    /**
     * @Glue
     */
    protected $text;

    public function html(): ?string
    {
        return '<input type="text" gphp-bind-value="text">';
    }
}

class Label extends AbstractComponent
{
    /**
     * @Glue
     */
    protected $text;

    public function html(): ?string
    {
        return '<label gphp-bind-html="text"></label>';
    }
}

class Button extends AbstractComponent
{
    /**
     * @Glue
     */
    protected $text = 'Click Me!';

    public function html(): ?string
    {
        return '<button gphp-bind-html="text" gphp-bind-events="click"></button>';
    }
}
